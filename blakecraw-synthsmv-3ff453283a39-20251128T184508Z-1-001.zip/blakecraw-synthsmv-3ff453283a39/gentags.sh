#!/bin/sh

## Create tags files to use with GNU GLOBAL.

cd NuSMV-modified/code;
gtags -v;
